# backend/main.py
from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware
import random

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DIALOGUE_DATA = {
    "default": ["designing", "......"],
    "click": ["designing"],
    
    # 首页逻辑
    "home_entry": ["designing"],
    "home_click": ["designing"],

    # 关于页 (About/WhoAmI) 逻辑 🔥
    # 统一支持 "about" 和 "whoami" 两个 ID 
    "about_entry": ["关于我"],
    "about_click": [ 
              "5hy1er无不良嗜好，但他就是想让我抽烟",
              "具体一点的话，我会出没于东湖长椅上，晚饭或什么的",
              "苹果普普通通，我也普普通通，放很久都不会坏，但我经常在校门口买到坏苹果",
              "今天吃早餐了吗？","今天没有早餐",
              "如果你天天吃早餐，我会默认你的生活已经步入正轨，非常的正",
              "其实我对文学一窍不通，这些都是装的，那就看我装吧",
              "这些文字大都写于一个小酒馆，一个冬天，与一只不嫌弃我的小猫，一位不嫌弃我的老板，我对此十分感激",
              "零零碎碎拼拼凑凑平平常常顺顺淡淡" ,
              "我很喜欢时至今日这个词，给人一种故事仍在继续的感觉",
              "我的语文很差，一直是，"
              "“我的脸很臭，但我经常唐笑弥补了这一点”",
              "“世界是一个巨大的棺材，我每天躺下练习葬礼，直到一天不再掀起被子”",
              "无助的隔壁 香芋追苹果 大口大口的喝",
              "其实我还想写点我喜欢的歌手，但是想来想去拿不定主意，索性就不写了",
              "东湖是一个好地方，没有什么人会侵犯我的长椅，但我会",
              "想到什么说什么，不太好",
              "shyler这个名字是怎么来的呢",
              "“眼里一片海，我却不肯蓝”",
              "about这页写了好多话，bb赖赖的",
              "你认识白色翻译家吗",
              "你认识黑色翻译家和褐色翻译家吗",
              "我在高中时期最喜欢的作家是鲁迅",
              "我对星座不敢兴趣，无论怎样看起来都像是对号入座，这种观测会在无形中干预种种",
              "我的MBTI是xswl",
              "我是后背",
                    ],
    "whoami_entry": ["designing"],
    "whoami_click": ["designing"],

    "bento_shyler": ["是你在时间我还是我在时间你"],
    "mouth": ["找到正确的语言", "你好。"],
    
    "6ydeco1_click":["厌学小姐不喜欢葱，香菜，火龙果等",
                "也不喜欢很辣的东西",
                "壁虎，是壁虎，吓她一跳",
                "记录厌学小姐的不喜欢中....."
                ],
    "6ydeco2_click":["'我就知道你在骂我'","......","嘻嘻，犯贱我猜厌学小姐就是这个表情"],
    "6ydeco3_click":["我也好想你","不过很快就能见面了"],
    "6ydeco4_click":["厌学小姐速通科目二，好厉害","你坐不坐我后面","带带我呗"],
    "6ydeco5_click":["不知道，你猜猜我放这只HelloKitty是什么意思"],
    "6ydeco6_click":["你就这样撩我吧","好甜蜜","一起洗澡啊","发只奶龙"],
    "6ydeco7_click":["一只奶龙版的厌学小姐","有点可爱","龙y","奖励一颗糖"],
    "6ydeco8_click":["认真学习的厌学小姐","xm100y","100y"],
    "6ydeco9_click":["喜欢薛之谦的一只小猫","和我一起听好呗"],
    "6ydeco10_click":["不知道此时的厌学小姐看到是什么心情"],
    "6ydeco11_click":["厌学小姐今年19，我在生日时给了她一个惊喜，她说，她很感动"],
    "6ydeco12_click":["你要吃了我吗","我以后做好吃的喂你","西蓝花小姐"],
    "6ydeco13_click":["骗你的，其实是我吃厌学小姐","厌学小姐爆汁儿了"],
    "whosheis_entry":["天天开心，厌学小姐"],
    "whosheis_click":["这里还有一点小恶心话说",
                      "我想你了,你想我不,看到扣1，没看到扣眼珠子",
                      "我想我们要走的路还会很长很长，我想不会离开你",
                      "想和你见面，我们什么都谈，不要责怪我的孤陋寡闻",
                      "想和你散步，我们什么话都不说，就这么走着",
                      "那几只小猫都有两三句小话，不知道你发现了没有",
                      "Aununo说的鬼话你别信，要是还有别的小女孩我给整这出能给我累死",
                      "唉我写到这里突然有个好主意，有些想说不敢说的悄悄话我说不定可以放在这里，等你来看",
                      "现在还只是一个demo，还得好好优化一下，不然一直刷会很累,博客那些还没有这么完善仔细的设计，随便看看吧",
                      "我不会忘记那些夜晚，我到死都会记得，我会把奶咯抱在胸口，感觉很踏实",
                      "感谢你同我分享那些日常，无论好坏",
                      "我还有好多好多想说的话，还有好多想做的事，等我一会呗",
                      "算上这条，总共有14条，不写多了，你要是运气背点说不定刷到这条几次了都没刷完",
                      "我无法衡量我现在的幸福，这是一种不同的归属"
                      ]

}

@app.post("/api/get-dialogue")
async def get_dialogue(data: dict = Body(...)):
    trigger_type = data.get("trigger_type", "default")
    page_id = data.get("page_id", "home")
    
    # 构造复合键：如 "about_entry"
    combined_key = f"{page_id}_{trigger_type}"
    
    # 优先级查找：
    # 1. 页面_动作 (如 about_click)
    if combined_key in DIALOGUE_DATA:
        choices = DIALOGUE_DATA[combined_key]
    # 2. 页面通用 (如 about)
    elif page_id in DIALOGUE_DATA:
        choices = DIALOGUE_DATA[page_id]
    # 3. 动作通用 (如 click)
    elif trigger_type in DIALOGUE_DATA:
        choices = DIALOGUE_DATA[trigger_type]
    else:
        choices = DIALOGUE_DATA["default"]
        
    return {"message": random.choice(choices)}

if __name__ == "__main__":
    import uvicorn
    # 确保端口与前端一致
    uvicorn.run(app, host="0.0.0.0", port=8000)