"use client"; // 🔥 必须添加这一行

import { BentoGrid, BentoCard } from "@/components/magicui/bento-grid";
import { FileTextIcon, Pencil1Icon } from "@radix-ui/react-icons";
import { Marquee } from "@/components/magicui/marquee"
import BrokenRecord from "@/components/magicui/broken-record";
import { PosterModule } from "@/components/magicui/PosterModule";
import { InteractiveEye } from "@/components/magicui/watcheye";
import { WhoAmI } from "@/components/magicui/whoami";
import { motion, AnimatePresence } from "framer-motion";
import React, { useState } from "react";
import { TV } from "@/components/magicui/tv";

export default function Home() {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [tvChannel, setTvChannel] = useState("/image/record/blackscreen.jpg");
  const [tvHref, setTvHref] = useState("#");
  
  const closePreview = () => setPreviewUrl(null);
  
  return (
    <main className={`relative min-h-screen bg-[#000488] overflow-x-hidden`}>
      {/* 氛围层：修复了之前 fixed absolute 并用的冗余 */}
      <div className={`fixed top-[40%] right-[-10%] w-[700px] h-[600px] bg-orange-500/35 blur-[120px] rounded-full pointer-events-none z-0`} />
      
      <TV 
        x={150} 
        y={0} 
        width={1200} 
        height={900} 
        xscreen={320}
        yscreen={260}
        wscreen={455} 
        hscreen={345}
        currentImage={tvChannel}
        href={tvHref}
      />

      <PosterModule 
        x={1200} y={200} 
        width={280} height={240} 
        zIndex={1} 
        image="/image/friends/she.jpg" 
        title="𝗔𝗯𝗼𝘂𝘁 her"
        href="/whosheis "
        description="我超喜欢"
        showTextAlways={true}
        hazy={false}
        softEdges={false}
        brightnessHover={true}
        isTransparent={true}
        flickerHover={true}
      />

      {/* 朋友圈/频道切换区域 */}
      <div onClick={() => {
        setTvChannel("/image/friends/3906blog.png");
        setTvHref("https://dx3906lxr.github.io/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1150} y={160} 
          width={140} height={140} 
          rotate={-2}
          image="/image/friends/3906.png" 
          hazy={false}
          isTransparent={true}
          title="DX3906"
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/hgsblog.png");
        setTvHref("https://www.cnblogs.com/Hanggoash");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1190} y={0} 
          width={140} height={140} 
          rotate={-180}
          zIndex={1}
          image="/image/friends/hgs.png" 
          hazy={false}
          isTransparent={true}
          title="ɥsɐoƃƃuɐH"
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/ninebird.png");
        setTvHref("https://www.n1n3bird.top/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={950} y={60} 
          width={160} height={160} 
          rotate={10}
          image="/image/friends/ninebird1.png" 
          hazy={false}
          isTransparent={true}
          title="N1n3bird" 
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/zenus10blog.png");
        setTvHref("https://zenus10.com");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={800} y={20} 
          width={120} height={200} 
          rotate={-7}
          image="/image/whoshewas.jpg" 
          hazy={false}
          isTransparent={true}
          title="Zenus10" 
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/rumublog.png");
        setTvHref("https://rumunius.top/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={900} y={130} 
          width={100} height={100}
          zIndex={100}
          rotate={-2}
          image="/image/friends/rumu2.png" 
          title="Rumu" 
          hazy={false}
          isTransparent={true}
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/ctyblog.png");
        setTvHref("https://notion-next-dx9u.vercel.app/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={680} y={60} 
          width={120} height={120} 
          rotate={0}
          image="/image/friends/cty1.png" 
          hazy={false}
          isTransparent={true}
          title="cty"
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/xzqblog1.png");
        setTvHref("https://github.com/T4nzQ");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1060} y={20} 
          width={160} height={160} 
          rotate={-2}
          gifImage="/image/friends/xzhiqiao.gif" 
          hazy={false}
          isTransparent={true}
          title="xiaozhiqiao"
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/oakblog.png");
        setTvHref("https://oakbutton.top/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1100} y={350} 
          width={140} height={140} 
          rotate={6}
          image="/image/friends/oakbutton1.png" 
          hazy={false}
          isTransparent={true}
          title='oakbutton'
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/fuxiblog.png");
        setTvHref("https://fuxi.host/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1260} y={530} 
          width={270} height={270} 
          rotate={6}
          image="/image/friends/fuxi1.png" 
          hazy={false}
          isTransparent={true}
          title='fuxi'
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/jerryblog.png");
        setTvHref("https://fallenjerry.cn/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1170} y={630} 
          width={170} height={170} 
          rotate={6}
          image="/image/friends/Jerry2.png" 
          hazy={false}
          isTransparent={true}
          title='Jerry'
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/zzxblog.png");
        setTvHref("https://cantsp3ak.com/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1380} y={480} 
          width={100} height={100} 
          rotate={-8}
          image="/image/friends/zzx.jpg" 
          hazy={false}
          isTransparent={true}
          title="canspeak"
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/lqhblog.png");
        setTvHref("https://milloong.github.io/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={550} y={110} 
          width={120} height={120} 
          rotate={0}
          gifImage="/image/friends/lqh2.gif" 
          isTransparent={true}
          title="Loongking"
          titleColor="black"
        />
      </div>

      {/* 游戏模块 */}
      <div onClick={() => {
        setTvChannel("/image/friends/steam.png");
        setTvHref("https://store.steampowered.com/");
      }} className={`cursor-pointer`}>
        <PosterModule
          x={1100} y={480} 
          width={250} height={150} 
          rotate={0}
          zIndex={1}
          image="/image/friends/rainworld.jpg"
          marqueeImages={[ 
            "/image/friends/Minecraft.jpg", 
            "/image/friends/Terraria.jpg", 
            "/image/friends/stardew.jpg", 
            "/image/friends/deadcells.jpg", 
            "/image/friends/hearthstone1.jpg", 
            "/image/friends/sts.jpg", 
            "/image/friends/outerwilds.jpg", 
            "/image/friends/rainworld.jpg"
          ]}
          hazy={true}
          showTextAlways={true}
          isTransparent={true}
          title="my favorate game"
        />
      </div>

      {/* 装饰与功能组件区域 */}
      <BrokenRecord />
      
      <div className={`fixed inset-0 pointer-events-none z-50`}>
        <InteractiveEye 
          x="89%" y="43%" size={100}
          frameImg="/image/eye/frame.png"
          irisImg="/image/eye/iris.png"
          blinkImg="/image/eye/frame.png"
        />
        <InteractiveEye 
          x="92%" y="31%" size={100}
          frameImg="/image/eye/frame.png"
          irisImg="/image/eye/iris.png"
          blinkImg="/image/eye/frame.png"
        />
      </div>

      <div onClick={() => {
        setTvChannel("/image/friends/whoami.png");
        setTvHref("/");
      }} className={`cursor-pointer`}>
        <PosterModule 
          x={60} y={200} 
          width={280} height={240} 
          zIndex={1} 
          image="/image/shyler11.jpg" 
          title="𝗔𝗯𝗼𝘂𝘁 𝗠𝗲"
          description="..............Hi there"
          showTextAlways={true}
          hazy={false}
          softEdges={false}
          brightnessHover={true}
          isTransparent={true}
          flickerHover={true}
        />
      </div>

      <PosterModule 
        x={160} y={20} 
        width={140} height={200} 
        rotate={3}
        zIndex={3}
        href="/friend"
        marqueeImages={[ 
          "/image/person3.jpg", 
          "/image/person1.jpg", 
          "/image/person2.jpg",
          "/image/person6.jpg",
          "/image/person7.jpg",
          "/image/person8.jpg",
          "/image/person9.jpg",
          "/image/person12.jpg",
        ]}
        title="Friends"
        description="𝓷𝓲𝓬𝓮 𝓽𝓸 𝓶𝓮𝓮𝓽 𝓾"
        softEdges={false}
        hazy={false}
        showTextAlways={true}
      />

      <WhoAmI 
        x={0} y={350} 
        width={500} height={500} 
        image="/image/friends/whoami.png"
        isTransparent={true}
        pageId="#"
      />

      <div className={`fixed inset-0 bg-orange-500/7 mix-blend-overlay pointer-events-none z-20`} />
    </main>
  );
}