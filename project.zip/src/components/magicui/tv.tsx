"use client";

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface TVProps {
  x?: number; y?: number; width?: number; height?: number;
  xscreen?: number | string; yscreen?: number | string;
  wscreen?: number | string; hscreen?: number | string;
  currentImage?: string; 
  tvFrameImg?: string;  
  href?: string;        
  className?: string;
}

export const TV = ({
  x = 380, y = 100, width = 800, height = 600,
  xscreen = "14%", yscreen = "15%", wscreen = "72%", hscreen = "58%",
  currentImage, 
  tvFrameImg = "/image/record/TV5.png", 
  href,
  className,
}: TVProps) => {
  const [noiseIndex, setNoiseIndex] = useState<number | null>(null);
  const [mounted, setMounted] = useState(false);
  const noiseTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;

    let count = 0;
    const interval = setInterval(() => {
      setNoiseIndex((count % 4) + 1); 
      count++;
    }, 50);

    noiseTimerRef.current = setTimeout(() => {
      clearInterval(interval);
      setNoiseIndex(null);
    }, 400);

    return () => {
      clearInterval(interval);
      if (noiseTimerRef.current) clearTimeout(noiseTimerRef.current);
    };
  }, [currentImage, mounted]);

  const handleJump = () => {
    if (href && href !== "#") {
      window.open(href, "_blank", "noopener,noreferrer");
    }
  };

  if (!mounted) return null;

  return (
    <div
      className={cn(`fixed z-[100] select-none pointer-events-none`, className)}
      style={{ left: x, top: y, width, height }}
    >
      <style jsx global>{`
        /* 核心动画保持不变 */
        @keyframes tv-jitter-global {
          0% { transform: translateY(0); }
          50% { transform: translateY(-1.5px); }
          100% { transform: translateY(0); }
        }
        @keyframes tv-flicker-global {
          0% { opacity: 0.85; filter: brightness(1.1); }
          100% { opacity: 1; }
        }
        @keyframes tv-scanline-global {
          from { transform: translateY(-100%); }
          to { transform: translateY(100%); }
        }
        .tv-jitter-layer { animation: tv-jitter-global 0.2s infinite; }
        .tv-flicker-layer { animation: tv-flicker-global 0.15s infinite; }
        .tv-scanline-scroller { animation: tv-scanline-global 4s linear infinite; }
        .tv-static-lines {
          background: repeating-linear-gradient(
            0deg,
            rgba(0, 0, 0, 0.4) 0px,
            rgba(0, 0, 0, 0.4) 1px,
            transparent 1px,
            transparent 3px
          );
        }
      `}</style>

      {/* 电视机外壳层 */}
      <img
        src={tvFrameImg}
        className={`absolute inset-0 w-full h-full object-contain z-50 pointer-events-none`}
        draggable={false}
      />

      <div 
        onClick={handleJump}
        className={cn(
          `absolute z-10 overflow-hidden bg-black pointer-events-auto`,
          href && href !== "#" ? `cursor-pointer` : `cursor-default`
        )}
        style={{ 
          top: yscreen, 
          left: xscreen, 
          width: wscreen, 
          height: hscreen, 
          borderRadius: '5px' 
        }}
      >
        {/* 图像显示层 */}
        <div className={`absolute inset-0 z-0`}>
          <AnimatePresence mode={`wait`}>
            {noiseIndex !== null ? (
              <motion.img 
                key={`noise`}
                src={`/image/record/no${noiseIndex}.png`} 
                initial={{ opacity: 1 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.1 }}
                className={`w-full h-full object-cover`} 
                alt={`noise`} 
              />
            ) : (
              <motion.img
                key={currentImage}
                src={currentImage}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.2 }}
                className={`w-full h-full object-cover`}
                alt={`content`}
              />
            )}
          </AnimatePresence>
        </div>

        {/* 特效叠加层 */}
        <div className={`absolute inset-0 z-10 tv-static-lines tv-jitter-layer pointer-events-none opacity-70`} />
        
        <div className={`absolute inset-0 z-20 pointer-events-none overflow-hidden opacity-30`}>
          <div className={`w-full h-24 bg-gradient-to-b from-transparent via-white/40 to-transparent tv-scanline-scroller`} />
        </div>

        <div className={`absolute inset-0 z-30 pointer-events-none tv-flicker-layer bg-white/[0.04] mix-blend-overlay`} />
        
        {/* 内凹阴影与调色 */}
        <div className={`absolute inset-0 z-40 pointer-events-none shadow-[inset_0_0_80px_rgba(0,0,0,0.95)]`} />
        <div className={`absolute inset-0 z-[41] pointer-events-none opacity-[0.12] bg-[linear-gradient(90deg,rgba(0,0,255,0.1),rgba(0,255,255,0.05),rgba(0,0,136,0.1))]`} />
      </div>
    </div>
  );
};