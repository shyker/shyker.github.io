"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";

export default function BrokenRecord() {
  const [isAssembled, setIsAssembled] = useState(false);
  const shards = Array.from({ length: 12 }, (_, i) => i + 1);

  const handleClick = () => {
    setIsAssembled(!isAssembled);
  };

  return (
    <div 
      className={`flex items-center justify-center cursor-pointer py-20`} 
      onClick={handleClick}
    >
      {/* 优化容器说明：
          1. animate-spin-slow 始终存在，确保动画状态不重置
          2. 使用 running / paused 控制旋转
          3. transform-gpu 强制启用硬件加速
      */}
      <div className={cn(
        `relative w-70 h-64 transition-transform duration-1000 ease-in-out transform-gpu`,
        `animate-spin-slow`, 
        isAssembled ? `scale-100 running` : `scale-90 paused` 
      )}>
        {shards.map((id) => (
          <div
            key={id}
            className={cn(
              `shard absolute inset-0 bg-cover bg-center transition-all duration-700`,
              `cubic-bezier(0.34, 1.56, 0.64, 1)`,
              `bg-[url('/image/record/record3.png')]`, 
              `shard-${id}`,
              // 当不聚合时，应用破碎位移类
              !isAssembled && `broken-shard-${id}`
            )}
            style={{
              pointerEvents: 'none' // 确保碎片不阻挡鼠标事件
            }}
          />
        ))}
        
        {/* 中心标签 */}
        <div className={cn(
            `absolute inset-0 m-auto w-16 h-16 rounded-full transition-opacity duration-700`,
            isAssembled ? `opacity-100` : `opacity-0`
        )} />
      </div>
    </div>
  );
}